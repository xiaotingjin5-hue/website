import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { FileBucket } from './local-server.mjs';
import worker from '../dist/server/index.js';
const temporary = await mkdtemp(join(tmpdir(), 'aura-package-check-'));
try {
  const env = { BUCKET: new FileBucket(temporary) };
  const request = (path, method = 'GET', body, token) => worker.fetch(new Request('http://localhost:8080' + path, {
    method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  }), env, {});
  assert.equal((await request('/')).status, 200);
  assert.equal((await request('/assets/aura-one.glb')).status, 200);
  assert.equal((await request('/assets/lune-box.glb')).status, 200);
  const room = await (await request('/api/rooms', 'POST', {})).json();
  assert.ok(room.id && room.token);
  const endpoint = '/api/rooms/' + room.id;
  const state = { product: 'lune', mode: 'explode', color: 'sage', status: 'live', camera: [4, 3, 5], target: [0, .34, 0] };
  assert.equal((await request(endpoint + '/state', 'PUT', state)).status, 403);
  assert.equal((await request(endpoint + '/state', 'PUT', state, room.token)).status, 200);
  assert.deepEqual((await (await request(endpoint + '/state')).json()).state.camera, [4, 3, 5]);
  assert.equal((await request(endpoint + '/event', 'POST', { client: 'local-test-viewer', type: 'back' })).status, 200);
  const events = await (await request(endpoint + '/events', 'GET', undefined, room.token)).json();
  assert.equal(events.events[0].requests[0].type, 'back');
  const persisted = new FileBucket(temporary);
  assert.equal((await (await persisted.get('rooms/' + room.id + '/state')).json()).product, 'lune');
  console.log('通过：页面资源、两款 GLB、本地持久化、控播权限、跨客户端状态和观众互动。');
} finally { await rm(temporary, { recursive: true, force: true }); }
