import http from 'node:http';
import { readFile, writeFile, mkdir, readdir, rename } from 'node:fs/promises';
import { resolve, dirname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import worker from '../dist/server/index.js';

export class FileBucket {
  constructor(root) { this.root = resolve(root); }
  path(key) {
    const path = resolve(this.root, key);
    if (!path.startsWith(this.root + sep)) throw new Error('Invalid storage key');
    return path;
  }
  async put(key, value) {
    const path = this.path(key);
    await mkdir(dirname(path), { recursive: true });
    const bytes = typeof value === 'string' ? Buffer.from(value) : Buffer.from(value);
    const temp = path + '.tmp-' + randomUUID();
    await writeFile(temp, bytes);
    await rename(temp, path);
  }
  async get(key) {
    try {
      const bytes = await readFile(this.path(key));
      return { json: async () => JSON.parse(bytes.toString('utf8')), body: bytes };
    } catch (error) {
      if (error.code === 'ENOENT') return null;
      throw error;
    }
  }
  async list({ prefix = '', limit = 1000 } = {}) {
    const keys = [];
    const walk = async (directory, relative = '') => {
      let entries;
      try { entries = await readdir(directory, { withFileTypes: true }); }
      catch (error) { if (error.code === 'ENOENT') return; throw error; }
      for (const entry of entries) {
        const key = relative ? relative + '/' + entry.name : entry.name;
        if (entry.isDirectory()) await walk(resolve(directory, entry.name), key);
        else if (!entry.name.includes('.tmp-') && key.startsWith(prefix)) keys.push(key);
      }
    };
    await walk(this.root);
    keys.sort();
    return { objects: keys.slice(0, limit).map(key => ({ key })), truncated: keys.length > limit };
  }
}

export function createLocalServer({ port = 8080, storage } = {}) {
  const project = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const bucket = new FileBucket(storage || resolve(project, '.local-data'));
  return http.createServer(async (incoming, outgoing) => {
    try {
      const chunks = [];
      let length = 0;
      for await (const chunk of incoming) {
        length += chunk.length;
        if (length > 32 * 1024 * 1024) {
          outgoing.writeHead(413, { 'Content-Type': 'text/plain;charset=utf-8' });
          outgoing.end('文件过大，最多支持 30 MB 的 GLB。');
          return;
        }
        chunks.push(chunk);
      }
      const url = new URL(incoming.url, 'http://localhost:' + port);
      const method = incoming.method || 'GET';
      const request = new Request(url, {
        method,
        headers: incoming.headers,
        body: ['GET', 'HEAD'].includes(method) ? undefined : Buffer.concat(chunks),
      });
      const response = await worker.fetch(request, { BUCKET: bucket }, {});
      outgoing.writeHead(response.status, Object.fromEntries(response.headers));
      outgoing.end(method === 'HEAD' ? undefined : Buffer.from(await response.arrayBuffer()));
    } catch (error) {
      console.error('Local request failed:', error.message);
      if (!outgoing.headersSent) outgoing.writeHead(500, { 'Content-Type': 'text/plain;charset=utf-8' });
      outgoing.end('本地服务暂时无法完成请求，请查看终端。');
    }
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 8080);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT 必须为 1–65535 的整数');
  const server = createLocalServer({ port });
  server.on('error', error => {
    console.error(error.code === 'EADDRINUSE' ? `端口 ${port} 已被占用，请设置其他 PORT 后重试。` : error.message);
    process.exitCode = 1;
  });
  server.listen(port, '127.0.0.1', () => {
    console.log(`\n物见 LIVE STUDIO 已启动\n浏览器打开：http://localhost:${port}\n按 Ctrl+C 停止。\n`);
  });
}
