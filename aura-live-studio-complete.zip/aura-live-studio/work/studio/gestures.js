import{FilesetResolver,HandLandmarker}from'@mediapipe/tasks-vision';
export async function startGestures(video,{onRotate,onZoom,onPause,onStatus,sensitivity=()=>3}){
const files=await FilesetResolver.forVisionTasks('/vision');let landmarker;try{landmarker=await HandLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:'/vision/hand.task',delegate:'GPU'},runningMode:'VIDEO',numHands:2,minHandDetectionConfidence:.65,minHandPresenceConfidence:.65,minTrackingConfidence:.65});}catch{landmarker=await HandLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:'/vision/hand.task',delegate:'CPU'},runningMode:'VIDEO',numHands:2,minHandDetectionConfidence:.65});}
let active=true,lastTime=-1,lastX=null,lastPinch=null,lastSpan=null,lastAt=0,pauseAt=0;
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);function tick(now){if(!active)return;requestAnimationFrame(tick);if(video.readyState<2||video.currentTime===lastTime||now-lastAt<65)return;lastTime=video.currentTime;lastAt=now;try{const result=landmarker.detectForVideo(video,now),hands=result.landmarks;if(!hands.length){lastX=lastPinch=lastSpan=null;onStatus('将手掌放在摄像头可见范围内');return;}const h=hands[0],palm=dist(h[0],h[9]),pinch=dist(h[4],h[8])/Math.max(palm,.02);const extended=[8,12,16,20].filter(i=>dist(h[i],h[0])>dist(h[i-2],h[0])*1.15).length;const gain=Number(sensitivity())/3;
if(hands.length===2){const span=dist(hands[0][0],hands[1][0]);if(lastSpan!==null&&Math.abs(span-lastSpan)>.005)onZoom(Math.exp((span-lastSpan)*gain*2.5));lastSpan=span;lastX=lastPinch=null;onStatus('双手展开 · 调节观察距离');return;}lastSpan=null;
if(extended===0&&pinch>.35){if(now-pauseAt>1200){onPause();pauseAt=now;}onStatus('握拳 · 已停止自动旋转');lastX=lastPinch=null;return;}
if(pinch<.85){if(lastPinch!==null&&Math.abs(pinch-lastPinch)>.008)onZoom(Math.exp(-(pinch-lastPinch)*gain*.75));lastPinch=pinch;lastX=null;onStatus('捏合 · 缩放商品');return;}lastPinch=null;
if(extended>=3){if(lastX!==null&&Math.abs(h[9].x-lastX)>.002)onRotate(-(h[9].x-lastX)*gain*4);lastX=h[9].x;onStatus('张掌横移 · 旋转商品');}else{lastX=null;onStatus('识别中 · 张掌或捏合进行控制');}
}catch(e){onStatus('识别暂时中断，请调整光线与手部位置');}}
requestAnimationFrame(tick);return()=>{active=false;landmarker.close();};}
