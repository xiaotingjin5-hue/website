import * as T from 'three';import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';import{writeFile}from'node:fs/promises';
globalThis.FileReader=class{readAsArrayBuffer(b){b.arrayBuffer().then(a=>{this.result=a;this.onloadend?.()})}};
const root=new T.Group();root.name='LUNE_Gift_Box';const shell=new T.MeshStandardMaterial({name:'shell',color:0x2e4a40,roughness:.68});const metal=new T.MeshStandardMaterial({name:'metal',color:0xba9e65,metalness:.85,roughness:.28});const lining=new T.MeshStandardMaterial({name:'cushion',color:0xdecfb4,roughness:1});const paper=new T.MeshStandardMaterial({name:'paper',color:0xe1dccf,roughness:.9});
const add=(name,geo,mat,pos,parent=root)=>{const m=new T.Mesh(geo,mat);m.name=name;m.position.set(...pos);parent.add(m);return m;};
const base=new T.Group();base.name='box_base';root.add(base);add('base_floor',new T.BoxGeometry(2.45,.12,1.78),shell,[0,-.86,0],base);
for(const s of[-1,1]){add('box_wall',new T.BoxGeometry(.10,.96,1.78),shell,[s*1.175,-.33,0],base);add('box_wall',new T.BoxGeometry(2.34,.96,.10),shell,[0,-.33,s*.84],base);}add('velvet_insert',new T.BoxGeometry(2.18,.13,1.54),lining,[0,-.69,0],base);
const inside=new T.Group();inside.name='box_contents';root.add(inside);
for(const x of[-.62,.62]){add('tea_tin',new T.CylinderGeometry(.34,.34,.66,64),paper,[x,-.28,0],inside);add('tin_lid',new T.CylinderGeometry(.355,.355,.06,64),metal,[x,.075,0],inside);add('tin_ring',new T.TorusGeometry(.30,.012,8,60),metal,[x,.115,0],inside).rotation.x=Math.PI/2;}
const lid=new T.Group();lid.name='box_lid';root.add(lid);add('lid_surface',new T.BoxGeometry(2.56,.16,1.88),shell,[0,.30,0],lid);add('lid_rim',new T.BoxGeometry(2.59,.035,1.91),metal,[0,.23,0],lid);add('lid_top',new T.BoxGeometry(2.46,.018,1.78),shell,[0,.39,0],lid);
const emblem=add('moon_emblem',new T.TorusGeometry(.24,.012,12,80),metal,[0,.413,0],lid);emblem.rotation.x=Math.PI/2;add('moon_line',new T.BoxGeometry(.6,.008,.012),metal,[0,.418,0],lid);
const handleCurve=new T.CatmullRomCurve3([new T.Vector3(-.33,.4,0),new T.Vector3(-.29,.76,0),new T.Vector3(0,.85,0),new T.Vector3(.29,.76,0),new T.Vector3(.33,.4,0)]);add('handle',new T.TubeGeometry(handleCurve,48,.022,12,false),metal,[0,0,0],lid);
const data=await new GLTFExporter().parseAsync(root,{binary:true});await writeFile('dist/assets/lune-box.glb',Buffer.from(data));console.log('Box GLB:',data.byteLength);
