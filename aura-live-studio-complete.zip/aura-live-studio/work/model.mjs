import * as T from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import {writeFile} from 'node:fs/promises';
globalThis.FileReader=class {readAsArrayBuffer(b){b.arrayBuffer().then(a=>{this.result=a;this.onloadend?.();});}};
const model=new T.Group();model.name='AURA_One';
const cream=new T.MeshStandardMaterial({name:'shell',color:0xe6e1d5,roughness:.29,metalness:.15});
const bronze=new T.MeshStandardMaterial({name:'metal',color:0xa98c6b,roughness:.26,metalness:.85});
const leather=new T.MeshStandardMaterial({name:'cushion',color:0xe8e2d8,roughness:.86});
const inner=new T.MeshStandardMaterial({name:'mesh',color:0x58544d,roughness:1});
const dark=new T.MeshStandardMaterial({name:'detail',color:0x716451,roughness:.5,metalness:.4});
function mesh(g,m,p=[0,0,0],parent=model){let o=new T.Mesh(g,m);o.position.set(...p);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
function arch(outerX,outerY,innerX,innerY,mat,depth,z){const s=new T.Shape();for(let i=0;i<=80;i++){let t=i/80*Math.PI;let x=outerX*Math.cos(t),y=.28+outerY*Math.sin(t);i?s.lineTo(x,y):s.moveTo(x,y);}for(let i=80;i>=0;i--){let t=i/80*Math.PI;s.lineTo(innerX*Math.cos(t),.28+innerY*Math.sin(t));}s.closePath();const g=new T.ExtrudeGeometry(s,{depth,bevelEnabled:true,bevelSegments:4,steps:1,bevelSize:.032,bevelThickness:.03,curveSegments:64});return mesh(g,mat,[0,0,z-depth/2]);}
arch(1.25,1.63,1.08,1.43,cream,.29,0);
arch(1.093,1.435,1.045,1.365,leather,.25,0);
for(let side of [-1,1]){
const g=new T.Group();g.position.set(side*1.03,-.44,0);g.rotation.z=side*-.11;model.add(g);
const shell=mesh(new T.SphereGeometry(1,64,48),cream,[0,0,0],g);shell.scale.set(.265,.71,.525);
const plate=mesh(new T.SphereGeometry(1,64,48),bronze,[side*.18,-.015,0],g);plate.scale.set(.16,.61,.455);
const disc=mesh(new T.SphereGeometry(1,64,48),bronze,[side*.285,-.015,0],g);disc.scale.set(.075,.53,.40);
const pad=mesh(new T.TorusGeometry(.385,.115,24,80),leather,[-side*.20,0,.015],g);pad.rotation.y=Math.PI/2;pad.scale.set(1,1.45,1);
const speaker=mesh(new T.SphereGeometry(1,40,28),inner,[-side*.19,0,0],g);speaker.scale.set(.045,.47,.315);
for(let i=-4;i<=4;i++){let line=mesh(new T.BoxGeometry(.008,.64,.005),dark,[-side*.237,0,i*.048],g);line.rotation.x=.12;}
const arm=mesh(new T.BoxGeometry(.12,.65,.18),cream,[-side*.035,.61,.0],g);arm.rotation.z=side*.06;
mesh(new T.SphereGeometry(.08,24,16),bronze,[side*.02,.36,.0],g).scale.set(.65,1,1);
for(let k=0;k<3;k++)mesh(new T.SphereGeometry(.018,12,8),dark,[side*.125,-.48,.25+k*.06],g);
const btn=mesh(new T.CapsuleGeometry(.025,.12,4,12),dark,[side*.20,-.46,.28],g);btn.rotation.x=.5;
}
model.userData={product:'AURA One',type:'Original concept demonstration',units:'meters'};
const data=await new GLTFExporter().parseAsync(model,{binary:true});await writeFile('dist/assets/aura-one.glb',Buffer.from(data));console.log('GLB generated:',data.byteLength,'bytes');
